#include "Recorder.h"

#include "HfConfig.h"

#include "ll/api/memory/Hook.h"
#include "ll/api/mod/NativeMod.h"

#include "mc/deps/core/utility/BinaryStream.h"
#include "mc/network/MinecraftPacketIds.h"
#include "mc/network/Packet.h"
#include "mc/network/ServerNetworkHandler.h"
#include "mc/network/packet/AnimatePacket.h"
#include "mc/network/packet/InteractPacket.h"
#include "mc/network/packet/PlayerAuthInputPacket.h"
#include "mc/server/ServerPlayer.h"
#include "mc/world/actor/player/Player.h"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstring>
#include <ctime>
#include <fstream>
#include <memory>
#include <utility>

namespace hf_replay {

// 取当前插件实例（用于日志与目录）
static ll::mod::Mod& self() { return *ll::mod::NativeMod::current(); }

static uint64_t nowMs() {
    return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

// ============================================================
//  拦包钩子
//
//  ★ 关键事实（照 LeviLamina 26.20.3 头文件核对）：
//    ServerNetworkHandler 只有「按包类型」的 handle 重载，
//    不存在通用的 handle(NetworkIdentifier const&, Packet const&)。
//    $handle 是各重载对应的内部符号，因此这里对每种白名单包
//    分别挂钩，并用 static_cast 消除重载歧义。
//
//  只在「录制中」才做判断，平时一次布尔读，零开销。
// ============================================================
using HfAuthInputFn = void (::ServerNetworkHandler::*)(::NetworkIdentifier const&, ::PlayerAuthInputPacket const&);
using HfAnimateFn   = void (::ServerNetworkHandler::*)(::NetworkIdentifier const&, ::AnimatePacket const&);
using HfInteractFn  = void (::ServerNetworkHandler::*)(::NetworkIdentifier const&, ::InteractPacket const&);

// ★ 三个钩子都用 #if 包住：关掉哪个包，那段代码就彻底不参与编译。
//   这样万一某个包的 handle 重载在这个版本里不存在，改个宏就能绕开，
//   不需要删代码。
//
//   头文件实证（ServerNetworkHandler.h）：这三个重载都存在
//     422: handle(NetworkIdentifier const&, AnimatePacket const&)
//     464: handle(NetworkIdentifier const&, InteractPacket const&)
//     495: handle(NetworkIdentifier const&, PlayerAuthInputPacket const&)

#if HF_CAPTURE_AUTH_INPUT
// 144 —— 移动/朝向/跳/潜行/冲刺/挖/放/用物品 全在这一个包里
LL_TYPE_INSTANCE_HOOK(
    HfHookAuthInput,
    ll::memory::HookPriority::Normal,
    ::ServerNetworkHandler,
    static_cast<HfAuthInputFn>(&::ServerNetworkHandler::$handle),
    void,
    ::NetworkIdentifier const&      source,
    ::PlayerAuthInputPacket const&  packet
) {
    hf_replay::Recorder::getInstance().tryCaptureAuthInput(source, packet);
    origin(source, packet);
}
#endif

#if HF_CAPTURE_ANIMATE
// 44 —— 挥手
LL_TYPE_INSTANCE_HOOK(
    HfHookAnimate,
    ll::memory::HookPriority::Normal,
    ::ServerNetworkHandler,
    static_cast<HfAnimateFn>(&::ServerNetworkHandler::$handle),
    void,
    ::NetworkIdentifier const& source,
    ::AnimatePacket const&     packet
) {
    hf_replay::Recorder::getInstance().tryCaptureAnimate(source, packet);
    origin(source, packet);
}
#endif

#if HF_CAPTURE_INTERACT
// 33 —— 攻击/交互
LL_TYPE_INSTANCE_HOOK(
    HfHookInteract,
    ll::memory::HookPriority::Normal,
    ::ServerNetworkHandler,
    static_cast<HfInteractFn>(&::ServerNetworkHandler::$handle),
    void,
    ::NetworkIdentifier const& source,
    ::InteractPacket const&    packet
) {
    hf_replay::Recorder::getInstance().tryCaptureInteract(source, packet);
    origin(source, packet);
}
#endif

Recorder& Recorder::getInstance() {
    static Recorder inst;
    return inst;
}

void Recorder::installHooks() {
    // 按 HfConfig.h 的白名单决定挂哪些钩子（默认三个全开）
#if HF_CAPTURE_AUTH_INPUT
    HfHookAuthInput::hook();
#endif
#if HF_CAPTURE_INTERACT
    HfHookInteract::hook();
#endif
#if HF_CAPTURE_ANIMATE
    HfHookAnimate::hook();
#endif
}

void Recorder::uninstallHooks() {
#if HF_CAPTURE_AUTH_INPUT
    if (HfHookAuthInput::isHooked()) HfHookAuthInput::unhook();
#endif
#if HF_CAPTURE_ANIMATE
    if (HfHookAnimate::isHooked()) HfHookAnimate::unhook();
#endif
#if HF_CAPTURE_INTERACT
    if (HfHookInteract::isHooked()) HfHookInteract::unhook();
#endif
}

std::filesystem::path Recorder::recordsDir() {
    return self().getModDir() / "records";
}

std::filesystem::path Recorder::dataDir() const {
    return recordsDir();
}

std::string Recorder::start(Player* target) {
    if (mRecording) return "当前正在录制，先停止再开始";
    if (!target) return "找不到该玩家";

    mTargetName = target->getName();
    mTarget     = target;
    mTargetNid  = target->getNetworkIdentifier();
    mPackets.clear();
    mChats.clear();
    mStartMs = nowMs();

    auto const& pos = target->getPosition();
    mStartPosX  = pos.x;
    mStartPosY  = pos.y;
    mStartPosZ  = pos.z;
    mStartDimId = static_cast<int32_t>(target->getDimensionId());

    mRecording = true;

    // 快照标签绑定这一次录制：玩家名 + 开录时刻。
    // 每录一段就有一份自己的快照，互相不覆盖，回放哪段还原哪段。
    mSnapTag = "snap_" + mTargetName + "_" + std::to_string(mStartMs);
    return "";
}

StopResult Recorder::stopAndSave() {
    StopResult res;
    if (!mRecording) {
        res.msg = "当前没有在录制";
        return res;
    }
    mRecording = false;

    size_t packetCount = mPackets.size();
    size_t chatCount   = mChats.size();
    if (packetCount == 0) {
        mTarget = nullptr;
        res.msg = "录制为空（没有捕捉到任何行为），已丢弃";
        return res;
    }

    std::time_t t = std::time(nullptr);
    std::tm     tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char suffix[32];
    std::strftime(suffix, sizeof(suffix), "%m%d_%H%M%S", &tm);

    std::string safe;
    for (char c : mTargetName) {
        if (std::isalnum((unsigned char)c) || c == '_' || c == '-') safe += c;
    }
    if (safe.empty()) safe = "player";
    std::string fname = safe + "_" + suffix + ".hfr";

    std::error_code ec;
    std::filesystem::create_directories(dataDir(), ec);
    std::filesystem::path path = dataDir() / fname;

    RecordFileHeader header{};
    // ★ magic 字段只有 8 字节，实际写进去的是 "HFREPLAY"（不带 1）。
    //   以前写成 memcpy(magic, "HFREPLAY1", 8)，第 9 个字符被截掉，
    //   让人以为文件头里有 "HFREPLAY1" —— 实际没有。这里写清楚，
    //   免得以后有人按 9 个字符去校验，永远对不上。
    std::memcpy(header.magic, "HFREPLAY", 8);
    header.version     = 1;
    header.packetCount = (uint32_t)packetCount;
    header.chatCount   = (uint32_t)chatCount;
    header.startPosX   = mStartPosX;
    header.startPosY   = mStartPosY;
    header.startPosZ   = mStartPosZ;
    header.startDimId  = mStartDimId;
    header.durationMs  = mPackets.back().first.timeMs;
    std::strncpy(header.targetName, mTargetName.c_str(), sizeof(header.targetName) - 1);

    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) {
        res.msg = "录制文件写入失败";
        return res;
    }

    out.write((char const*)&header, sizeof(header));

    // 按时间序交错写入：包 + 聊天
    size_t chatIdx = 0;
    for (auto const& [h, bytes] : mPackets) {
        while (chatIdx < mChats.size() && mChats[chatIdx].first.timeMs <= h.timeMs) {
            auto const& [ch, text] = mChats[chatIdx];
            RecordPacketEntry ce = ch; // entryType=2, packetId=0, timeMs 已就绪
            ce.dataLen = (uint32_t)text.size();
            out.write((char const*)&ce, sizeof(ce));
            out.write(text.data(), ce.dataLen);
            chatIdx++;
        }
        RecordPacketEntry pe = h; // entryType=1, packetId, timeMs 已就绪
        out.write((char const*)&pe, sizeof(pe));
        out.write((char const*)bytes.data(), (std::streamsize)bytes.size());
    }
    while (chatIdx < mChats.size()) {
        auto const& [ch, text] = mChats[chatIdx];
        RecordPacketEntry ce = ch;
        ce.dataLen = (uint32_t)text.size();
        out.write((char const*)&ce, sizeof(ce));
        out.write(text.data(), ce.dataLen);
        chatIdx++;
    }
    out.close();

    mTarget = nullptr;
    res.ok  = true;
    res.msg = path.string();
    return res;
}

void Recorder::storePacket(::Packet const& packet, uint32_t packetId) {
    try {
        ::BinaryStream stream;
        packet.write(stream); // 包自己序列化自己，一字不改

        // BinaryStream::mBuffer 是 std::string&（指向内部缓冲），不是 optional/智能指针
        auto const& buf = stream.mBuffer;
        std::vector<uint8_t> bytes(buf.begin(), buf.end());

        RecordPacketEntry h{};
        h.entryType = 1;
        h.packetId  = packetId;
        h.timeMs    = nowMs() - mStartMs;
        h.dataLen   = (uint32_t)bytes.size();
        mPackets.emplace_back(h, std::move(bytes));
    } catch (std::exception const& e) {
        self().getLogger().warn("录制序列化失败 id={}: {}", packetId, e.what());
    } catch (...) {
        self().getLogger().warn("录制序列化失败 id={}", packetId);
    }
}

void Recorder::tryCaptureAuthInput(::NetworkIdentifier const& nid, ::PlayerAuthInputPacket const& packet) {
    if (!mRecording || !(nid == mTargetNid)) return;
    // 注意枚举名带 Packet 后缀
    storePacket(packet, (uint32_t)::MinecraftPacketIds::PlayerAuthInputPacket);
}

void Recorder::tryCaptureAnimate(::NetworkIdentifier const& nid, ::AnimatePacket const& packet) {
    if (!mRecording || !(nid == mTargetNid)) return;
    storePacket(packet, (uint32_t)::MinecraftPacketIds::Animate); // 44
}

void Recorder::tryCaptureInteract(::NetworkIdentifier const& nid, ::InteractPacket const& packet) {
    if (!mRecording || !(nid == mTargetNid)) return;
    storePacket(packet, (uint32_t)::MinecraftPacketIds::Interact); // 33
}

void Recorder::tryCaptureChat(Player* player, std::string const& message) {
    if (!mRecording) return;
    if (!player || player->getName() != mTargetName) return;
    RecordPacketEntry h{};
    h.entryType = 2;
    h.packetId  = 0;
    h.timeMs    = nowMs() - mStartMs;
    h.dataLen   = (uint32_t)message.size();
    mChats.emplace_back(h, message);
}

} // namespace hf_replay
