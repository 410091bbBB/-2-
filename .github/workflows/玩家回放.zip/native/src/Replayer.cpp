#include "Replayer.h"

#include "HfConfig.h"

#include "ll/api/mod/NativeMod.h"
#include "ll/api/service/Bedrock.h"
#include "ll/api/thread/ServerThreadExecutor.h"

#include "mc/deps/core/math/Vec2.h"
#include "mc/deps/core/math/Vec3.h"
#include "mc/deps/core/utility/BinaryStream.h"
#include "mc/deps/core/utility/ReadOnlyBinaryStream.h"
#include "mc/network/MinecraftPacketIds.h"
#include "mc/network/Packet.h"
#include "mc/network/ServerNetworkHandler.h"
#include "mc/network/packet/AnimatePacket.h"
#include "mc/network/packet/InteractPacket.h"
#include "mc/network/packet/PlayerAuthInputPacket.h"
#include "mc/network/packet/TextPacket.h"
#include "mc/server/ServerPlayer.h"
#include "mc/server/SimulatedPlayer.h"
#include "mc/world/actor/player/Player.h"

#include <chrono>
#include <cstring>
#include <fstream>
#include <optional>
#include <string>
#include <utility>

namespace hf_replay {

// 取当前插件实例（用于日志）
static ll::mod::Mod& self() { return *ll::mod::NativeMod::current(); }

// 统一日志出口，受 HfConfig.h 里 LogLevel 控制
template <typename... Args>
static void hfLog(int level, char const* fmt, Args&&... args) {
    if (level <= cfg::LogLevel) {
        self().getLogger().info(fmt, std::forward<Args>(args)...);
    }
}

Replayer& Replayer::getInstance() {
    static Replayer inst;
    return inst;
}

static uint64_t nowMs() {
    return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
}

// 向全场公告（TextPacket 只暴露 createRawMessage，没有 createSystemMessage）
static void broadcast(std::string const& msg) {
    try {
        auto pkt = ::TextPacket::createRawMessage(msg);
        pkt.sendToClients();
    } catch (...) {
        // 广播失败不影响回放本身
    }
}

// ============================================================================
//  创建假人
//  ★ 头文件实证：SimulatedPlayer::create 返回【裸指针 SimulatedPlayer*】，
//    必须传 NotNullNonOwnerPtr<ServerNetworkHandler> + xuid。
//    （早期版本写成 optional_ref + 三参调用，是错的，已修正。）
// ============================================================================
::SimulatedPlayer* Replayer::createBot(std::string const& name, ::Vec3 const& pos, int dimId) {
    auto* handler = ll::service::getServerNetworkHandler().as_ptr();
    if (!handler) {
        hfLog(0, "[HF] 服务端网络处理器不可用，无法创建假人");
        return nullptr;
    }

    // ★ 用 #if 而非 if constexpr —— 只有 #if 能真正把没选中的写法从源码里裁掉。
    //   （普通函数里的 if constexpr 假分支照样要编过，那多写几套就没意义了）
#if HF_BOT_PLAN == 3
    // Plan C：不创建假人（用于单独验证录制链路）
    hfLog(0, "[HF] BotPlan=3：跳过假人创建，只验证录制");
    (void)name;
    (void)pos;
    (void)dimId;
    return nullptr;
#else
    ::SimulatedPlayer* sp = nullptr;

  #if HF_BOT_PLAN == 1
    // Plan A：六参重载（SimulatedPlayer.h:233）
    sp = ::SimulatedPlayer::create(
        name,
        pos,
        static_cast<::DimensionType>(dimId),
        ::Bedrock::NotNullNonOwnerPtr<::ServerNetworkHandler>(handler),
        std::string{"0"},      // xuid：假人不需要真实账号
        std::nullopt           // 不指定实体 ID，交给服务器分配
    );
  #else
    // Plan B：九参重载（SimulatedPlayer.h:242）
    // ★ 头文件实证：这个重载正好【9 个参数】，不是 10 个。
    //   早期草稿多写了一个 nullopt，会直接编不过，已删。
    sp = ::SimulatedPlayer::create(
        name,
        pos,
        ::Vec3{0, 0, 0},      // spawnPosDelta
        ::Vec2{0, 0},         // spawnRotation
        false,                // spawnLoadedFromSave
        static_cast<::DimensionType>(dimId),
        ::Bedrock::NotNullNonOwnerPtr<::ServerNetworkHandler>(handler),
        std::string{"0"},     // xuid
        std::nullopt          // idOverride
    );
  #endif

    return sp;
#endif
}

std::string Replayer::start(std::filesystem::path const& file) {
    if (mPlaying) return "当前已有回放在进行";

    std::ifstream in(file, std::ios::binary);
    if (!in) return "录制文件读取失败";

    RecordFileHeader h{};
    if (!in.read((char*)&h, sizeof(h))) return "录制文件损坏";
    // ★ 只比前 8 个字节，内容是 "HFREPLAY"（magic 字段就 8 字节，没有那个 1）
    if (std::memcmp(h.magic, "HFREPLAY", 8) != 0) return "这不是有效的录制文件";

    mEntries.clear();
    uint64_t const count = (uint64_t)h.packetCount + (uint64_t)h.chatCount;
    for (uint64_t i = 0; i < count; ++i) {
        RecordPacketEntry e{};
        if (!in.read((char*)&e, sizeof(e))) break;
        ReplayEntry re;
        re.entryType = e.entryType;
        re.packetId  = e.packetId;
        re.timeMs    = e.timeMs;
        re.data.resize(e.dataLen);
        if (e.dataLen) in.read(re.data.data(), e.dataLen);
        mEntries.push_back(std::move(re));
    }
    if (mEntries.empty()) return "录制内容为空";

    mBotName     = "HF_" + file.stem().string();
    mCurrentFile = file.filename().string();

    // 假人从录制起点的位置登场，这样第一帧输入才对得上
    ::Vec3 spawnPos{h.startPosX, h.startPosY, h.startPosZ};
    mBot = createBot(mBotName, spawnPos, h.startDimId);

#if HF_BOT_PLAN == 3
    mPlaying = true;
    mNext    = 0;
    mStartMs = nowMs();
    hfLog(1, "[HF] 无假人模式：开始跑时间轴（用来验证录制数据本身）");
    scheduleNext(1);
    return "";
#endif

    if (!mBot) return "假人创建失败（试试把 HfConfig.h 里 BotPlan 改成 2）";

    mBotNid      = mBot->getNetworkIdentifier();
    mNext        = 0;
    mPlayedCount = 0;
    mStartMs     = nowMs();
    mPlaying     = true;

    // 保护假人：免得围观玩家把它打死，导致后半场回放崩坏。
    // 用 #if —— 万一这个版本没有 setInvulnerable，
    // 把 HfConfig.h 里的 HF_PROTECT_BOT 改成 0 就能整段不参与编译。
#if HF_PROTECT_BOT
    try {
        mBot->setInvulnerable(true);
    } catch (...) {
    }
#endif

    // 等 5 tick 让假人完全进入世界，再吐第一个包
    scheduleNext(5);

    hfLog(1, "[HF] 回放开始: {} ({} 条记录, {} ms, FeedPlan={})",
          mCurrentFile, mEntries.size(), h.durationMs, cfg::FeedPlan);
    return "";
}

void Replayer::scheduleNext(int delayTicks) {
    ll::thread::ServerThreadExecutor::getDefault().executeAfter(
        [this]() { step(); },
        ll::chrono::ticks{delayTicks}
    );
}

// ============================================================================
//  每 tick：把到期的原始字节灌回包对象，再原样喂给服务端
//
//  ★ 喂包有两条路（HfConfig.h → FeedPlan）：
//     静态 handle(Player*, PlayerAuthInputPacket const&)
//       —— 直接对假人对象喂，不经过网络标识查表。
//          SimulatedPlayer 是服务端本地造的，NID 未必查得到玩家，
//          所以这条路风险最低。
//     实例 handle(nid, packet)
//       —— 走完整网络通道，但依赖假人 NID 能被正确解析。
//
//  ★ 注意：静态重载只有 PlayerAuthInputPacket 才有；
//     Animate(44) / Interact(33) 只能走实例 handle。
//     所以即使 FeedPlan=1，挥手和攻击交互仍走网络通道——
//     万一 NID 不通，表现为「会走会挖但不会挥手打人」，移动不受影响。
// ============================================================================
void Replayer::step() {
    if (!mPlaying) return;

    auto* handler = ll::service::getServerNetworkHandler().as_ptr();
    if (!handler) {
        finish(false);
        return;
    }

    uint64_t const elapsed = nowMs() - mStartMs;

    try {
        while (mNext < mEntries.size() && mEntries[mNext].timeMs <= elapsed) {
            ReplayEntry const& e = mEntries[mNext++];

            // ---- 聊天：原文广播 ----
            if (e.entryType == 2) {
                broadcast("[" + mBotName + "] " + e.data);
                continue;
            }

#if HF_BOT_PLAN == 3
            // 无假人模式：只推进计数，验证「时间轴能不能走通」。
            // 千万别把包喂出去 —— mBot 是空的，mBotNid 也是空壳，
            // 喂给 handle 的结果不可预料。
            ++mPlayedCount;
#else
            // ---- 原始字节 → 包对象（包自己反序列化自己，一字不改）----
            ::std::string_view sv(e.data.data(), e.data.size());
            ::ReadOnlyBinaryStream ros(sv, false);

            if (e.packetId == (uint32_t)::MinecraftPacketIds::PlayerAuthInputPacket) {
                ::PlayerAuthInputPacket p;
                p.read(ros);

                // ★ 同理，这里也必须 #if：三条路里只留一条参与编译，
                //   另外两条压根不存在，不可能因为它们报错。
  #if HF_FEED_PLAN == 1
                if (mBot) {
                    ::ServerNetworkHandler::handle(static_cast<::Player*>(mBot), p);
                }
  #elif HF_FEED_PLAN == 2
                handler->handle(mBotNid, p);
  #else
                // Plan 3：双通道都来一遍（排错用，正常不要开，会导致动作重复）
                if (mBot) ::ServerNetworkHandler::handle(static_cast<::Player*>(mBot), p);
                handler->handle(mBotNid, p);
  #endif
                ++mPlayedCount;
            } else if (e.packetId == (uint32_t)::MinecraftPacketIds::Animate) {
                ::AnimatePacket p;
                p.read(ros);
                handler->handle(mBotNid, p); // 无静态重载，只能走网络通道
                ++mPlayedCount;
            } else if (e.packetId == (uint32_t)::MinecraftPacketIds::Interact) {
                ::InteractPacket p;
                p.read(ros);
                handler->handle(mBotNid, p); // 同上
                ++mPlayedCount;
            } else {
                continue; // 未收录的包类型直接跳过
            }
#endif // HF_BOT_PLAN != 3

  #if HF_LOG_LEVEL >= 2
            hfLog(2, "[FEED] id={} t={}ms", e.packetId, e.timeMs);
  #endif
        }
    } catch (std::exception const& ex) {
        self().getLogger().error("回放异常，已终止: {}", ex.what());
        finish(false);
        return;
    } catch (...) {
        self().getLogger().error("回放异常，已终止");
        finish(false);
        return;
    }

    if (mNext >= mEntries.size()) {
        finish(true);
        return;
    }
    scheduleNext(1); // 下一 tick 继续吐到期的包
}

void Replayer::finish(bool completed) {
    mPlaying = false;
    broadcast(completed ? "§e[回放]§f 播放完毕（假人仍在场，不要了就 /hf 4）"
                        : "§e[回放]§c 播放中断");
    hfLog(1, "[HF] 回放结束({}) 已重放 {} 条", completed ? "完整" : "中断", mPlayedCount);
}

std::string Replayer::stop(bool removeBot) {
    if (!mPlaying) return "当前没有在回放";
    mPlaying = false; // 排队中的 step 会因 mPlaying=false 直接返回
    if (removeBot) cleanupBot();
    hfLog(1, "[HF] 回放被手动停止，已重放 {} 条", mPlayedCount);
    return "";
}

void Replayer::cleanupBot() {
    if (!mBot) return;
    try {
        mBot->disconnect(); // ServerPlayer::disconnect()
        mBot->remove();     // Actor::remove()
    } catch (...) {
    }
    mBot = nullptr;
}

} // namespace hf_replay
