#pragma once

// ============================================================
//  hf-replay / Recorder.h —— 录制层
//
//  架构（一句话）：
//    玩家在服务端的一切行为，本质上是一个每 tick 一条的
//    PlayerAuthInputPacket（协议 ID 144）输入流 + 少量补充包。
//    本层只做一件事：把录制目标的原始输入包【原封不动】存成字节，
//    不解析、不翻译、不理解内容。
//
//  采集白名单（实际挂钩的三种包，HfConfig.h 里可单独关掉）：
//    144 PlayerAuthInput  —— 位置/朝向/按键位集/跳/潜行/冲刺/游泳/滑翔/
//                             挖方块/放方块/用物品
//    33  Interact          —— 攻击/交互实体
//    44  Animate           —— 挥手
//  聊天不走包：用 LeviLamina 的 PlayerChatEvent 记录原文，
//  回放时用 TextPacket::createRawMessage 原文广播。
//
//  47 MobEquipment（切换手持物品）这一版**故意没录**：
//  回放端还没实现「给假人换手持」，录了数据也用不上，白占文件。
//  二期做手持同步时再加回来。
// ============================================================

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include "mc/network/NetworkIdentifier.h"

class Packet;
class Player;
class PlayerAuthInputPacket;
class AnimatePacket;
class InteractPacket;

namespace hf_replay {

// 统一记录条目（文件里每条 = 20字节头 + data）
//   entryType = 1 : data 是包体原始字节, packetId 有效
//   entryType = 2 : data 是聊天文本 UTF-8, packetId = 0
struct RecordPacketEntry {
    uint32_t entryType;
    uint32_t packetId;
    uint32_t dataLen;
    uint64_t timeMs;
};

// 录制文件头（纯二进制）
#pragma pack(push, 1)
struct RecordFileHeader {
    char     magic[8];     // "HFREPLAY1"
    uint32_t version;      // 1
    char     targetName[64];
    uint32_t packetCount;  // type=1 条数
    uint32_t chatCount;    // type=2 条数
    float    startPosX;
    float    startPosY;
    float    startPosZ;
    int32_t  startDimId;
    uint64_t durationMs;
};
#pragma pack(pop)

struct StopResult {
    bool        ok = false;
    std::string msg; // ok=true 时是文件路径，否则是错误说明
};

class Recorder {
public:
    static Recorder& getInstance();

    static std::filesystem::path recordsDir(); // 录制文件目录（命令层共用）

    void installHooks();   // enable 时调用
    void uninstallHooks(); // disable 时调用

    // 开始录制某个玩家。返回空串 = 成功，否则为错误信息
    std::string start(Player* target);

    // 停止并保存。StopResult
    StopResult stopAndSave();

    bool    isRecording() const { return mRecording; }
    Player* target() const { return mTarget; }

    // 本次录制配套快照的标签（start() 时生成，唯一）。
    // 快照必须和录制一一对应 —— 如果所有录制共用一个固定标签，
    // 第二次录制会覆盖第一次的快照，回放第一段时还原的就是
    // 第二段开头的世界，位置对不上，动作全变形。
    std::string const& snapTag() const { return mSnapTag; }

    // 由网络钩子调用。
    // BDS 的 ServerNetworkHandler 没有通用的 handle(NetworkIdentifier, Packet) 重载，
    // 只有针对每种包类型的重载，所以这里按类型分别挂钩、分别捕获。
    void tryCaptureAuthInput(::NetworkIdentifier const& nid, ::PlayerAuthInputPacket const& packet);
    void tryCaptureAnimate(::NetworkIdentifier const& nid, ::AnimatePacket const& packet);
    void tryCaptureInteract(::NetworkIdentifier const& nid, ::InteractPacket const& packet);

    // 由聊天事件调用
    void tryCaptureChat(Player* player, std::string const& message);

private:
    Recorder() = default;

    // 把包原样序列化成字节存下来（不解析内容）
    void storePacket(::Packet const& packet, uint32_t packetId);

    bool              mRecording = false;
    Player*           mTarget    = nullptr;
    ::NetworkIdentifier mTargetNid{};
    std::string       mTargetName;
    std::string       mSnapTag;   // 本次录制配套的快照标签
    uint64_t          mStartMs = 0;

    float   mStartPosX = 0, mStartPosY = 0, mStartPosZ = 0;
    int32_t mStartDimId = 0;

    std::vector<std::pair<RecordPacketEntry, std::vector<uint8_t>>> mPackets;
    std::vector<std::pair<RecordPacketEntry, std::string>>          mChats;

    std::filesystem::path dataDir() const;
};

} // namespace hf_replay
