#pragma once

// ============================================================================
//  hf-replay / Replayer.h —— 回放层
//
//  原样重放：读入 .hfr（录制时包自己序列化出来的原始字节），
//  按原始时间戳在服务端线程逐条灌回包对象，再喂给服务端。
//
//  服务端把假人当成真玩家来「重新算」这些输入 —— 零翻译、零适配。
//  这就是「录制级」的含义：不是告诉假人去做什么，而是让它把当时真正
//  发生过的输入再走一遍。
// ============================================================================

#include "Recorder.h"

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include "mc/network/NetworkIdentifier.h"

class Player;
class SimulatedPlayer;
class Vec3;

namespace hf_replay {

struct ReplayEntry {
    uint32_t    entryType; // 1 包 / 2 聊天
    uint32_t    packetId;
    uint64_t    timeMs;
    std::string data;      // 包体字节 或 聊天文本
};

class Replayer {
public:
    static Replayer& getInstance();

    // 开始回放一个 .hfr 文件。返回空串 = 成功，否则错误信息
    std::string start(std::filesystem::path const& file);

    // 停止回放。removeBot=true 时把假人踢下线
    std::string stop(bool removeBot);

    bool isPlaying() const { return mPlaying; }
    std::string const& currentFile() const { return mCurrentFile; }

    // 供命令层查询：当前假人是否还在（BotPlan=3 时可能为 null）
    bool hasBot() const { return mBot != nullptr; }

private:
    Replayer() = default;

    void              step();               // 服务端线程上按节拍吐包
    void              scheduleNext(int delayTicks);
    void              finish(bool completed);
    void              cleanupBot();
    ::SimulatedPlayer* createBot(std::string const& name, ::Vec3 const& pos, int dimId);

    std::atomic<bool>  mPlaying{false};
    ::SimulatedPlayer* mBot = nullptr;
    ::NetworkIdentifier mBotNid{};

    std::vector<ReplayEntry> mEntries;
    size_t   mNext        = 0;
    uint64_t mStartMs     = 0;
    uint64_t mPlayedCount = 0;
    std::string mBotName;
    std::string mCurrentFile;
};

} // namespace hf_replay
