#include "Commands.h"

#include "HfConfig.h"
#include "Recorder.h"
#include "Replayer.h"
#include "Snapshot.h"

#include "ll/api/command/CommandHandle.h"
#include "ll/api/command/CommandRegistrar.h"
#include "ll/api/mod/NativeMod.h"

#include "mc/network/packet/TextPacket.h"
#include "mc/server/commands/CommandOrigin.h"
#include "mc/server/commands/CommandOutput.h"
#include "mc/server/commands/CommandPermissionLevel.h"
#include "mc/world/actor/Actor.h"
#include "mc/world/actor/ActorType.h"
#include "mc/world/actor/player/Player.h"

#include <algorithm>
#include <filesystem>
#include <string>
#include <vector>

namespace hf_replay {

// 快照统一用这个名字：录制开始时拍，回放前恢复。
// 简单够用，不做多版本快照管理（那是二期的事）。
static constexpr char const* kSnapTag = "last";

static ll::mod::Mod& self() { return *ll::mod::NativeMod::current(); }

static ::Player* originPlayer(::CommandOrigin const& origin) {
    auto* actor = origin.getEntity();
    if (!actor) return nullptr;
    if (!actor->isType(::ActorType::Player)) return nullptr;
    return static_cast<::Player*>(actor);
}

static std::vector<std::filesystem::path> listFiles() {
    std::vector<std::filesystem::path> files;
    std::error_code                    ec;
    auto                               dir = Recorder::recordsDir();
    if (!std::filesystem::exists(dir, ec)) return files;
    for (auto const& entry : std::filesystem::directory_iterator(dir, ec)) {
        if (entry.path().extension() == ".hfr") files.push_back(entry.path());
    }
    std::sort(files.begin(), files.end()); // 文件名含时间戳，字典序即时间序
    return files;
}

// ============================================================================
//  所有子命令的实际逻辑集中在这里。
//  命令（CmdPlan=1）和聊天兜底（CmdPlan=2）两条路共用同一份实现，
//  所以切换方案不会导致行为不一致。
// ============================================================================
struct HfResult {
    bool        ok  = true;
    std::string msg;
};

static HfResult runSub(::Player* pl, int sub, int arg) {
    switch (sub) {
    case 1: { // 开始录制（顺手把世界拍下来）
        if (!pl) return {false, "这个命令必须由玩家在游戏里输入"};
        auto& rec = Recorder::getInstance();
        auto err = rec.start(pl);
        if (!err.empty()) return {false, err};

        std::string snapMsg;
#if (HF_SNAPSHOT_BLOCK || HF_SNAPSHOT_TILE)
        {
            // 快照标签由 Recorder 生成，和这次录制一一对应（见 Recorder.h）
            auto serr = Snapshot::getInstance().capture(pl, cfg::SnapshotRadius, rec.snapTag());
            if (serr.empty()) {
                size_t b = 0, t = 0;
                Snapshot::getInstance().stats(rec.snapTag(), b, t);
                snapMsg = "（已顺手拍下世界快照：" + std::to_string(b) + " 方块 / "
                        + std::to_string(t) + " 容器）";
            } else {
                snapMsg = "（快照失败：" + serr + "，回放时世界不会被还原）";
            }
        }
#endif
        return {true, "§a开始录制你的行为，去干你想干的事。完成输入 /hf 2 " + snapMsg};
    }

    case 2: { // 停止并保存
        auto r = Recorder::getInstance().stopAndSave();
        if (!r.ok) return {false, r.msg};
        return {true, "§a录制完成，已保存。输入 /hf 3 就能回放"};
    }

    case 3: { // 回放（回放前先把世界恢复成录制起点的样子）
        auto files = listFiles();
        if (files.empty()) return {false, "还没有任何录制，先用 /hf 1 录一段"};

        size_t idx = files.size(); // 默认最新
        if (arg >= 1) {
            if ((size_t)arg > files.size()) return {false, "编号不存在，用 /hf 5 看列表"};
            idx = (size_t)arg - 1;
        } else {
            idx = files.size() - 1;
        }

        std::string restoreMsg;
#if (HF_SNAPSHOT_BLOCK || HF_SNAPSHOT_TILE)
        {
            // 还原「最近一次录制」配套的那份快照。
            // 录制和快照是一一对应的（标签里带玩家名和开录时刻），
            // 不会出现“回放第一段、还原的却是第二段开头”的错位。
            auto const& tag = Recorder::getInstance().snapTag();
            if (Snapshot::getInstance().has(tag)) {
                auto rerr = Snapshot::getInstance().restore(tag);
                restoreMsg = rerr.empty() ? "（世界已还原到录制起点）"
                                          : "（世界还原失败：" + rerr + "）";
            } else {
                restoreMsg = "（没有快照，世界保持现状）";
            }
        }
#endif

        auto err = Replayer::getInstance().start(files[idx]);
        if (!err.empty()) return {false, err};
        return {true, "§a回放开始 " + restoreMsg + " 停止用 /hf 4"};
    }

    case 4: { // 停止回放并移除假人
        auto err = Replayer::getInstance().stop(true);
        if (!err.empty()) return {false, err};
        return {true, "已停止回放，假人已下线"};
    }

    case 5: { // 列表
        auto files = listFiles();
        if (files.empty()) return {true, "还没有任何录制。用 /hf 1 开始第一段"};
        std::string s = "共 " + std::to_string(files.size()) + " 段录制：";
        for (size_t i = 0; i < files.size(); ++i) {
            s += "\n  " + std::to_string(i + 1) + ". " + files[i].stem().string();
        }
        return {true, s};
    }

    case 6: { // 删除
        auto files = listFiles();
        if (arg < 1 || (size_t)arg > files.size()) return {false, "编号不存在，用 /hf 5 看列表"};
        std::error_code ec;
        auto const&     f = files[(size_t)arg - 1];
        if (!std::filesystem::remove(f, ec)) return {false, "删除失败"};
        return {true, "已删除：" + f.stem().string()};
    }

    case 7: { // 手动拍快照
        if (!pl) return {false, "必须由玩家输入"};
        int r = arg > 0 ? arg : cfg::SnapshotRadius;
        auto serr = Snapshot::getInstance().capture(pl, r, kSnapTag);
        if (!serr.empty()) return {false, serr};
        size_t b = 0, t = 0;
        Snapshot::getInstance().stats(kSnapTag, b, t);
        return {true, "快照完成：" + std::to_string(b) + " 方块 / " + std::to_string(t) + " 容器"};
    }

    case 8: { // 手动恢复快照
        if (!Snapshot::getInstance().has(kSnapTag)) return {false, "还没有快照"};
        auto rerr = Snapshot::getInstance().restore(kSnapTag);
        if (!rerr.empty()) return {false, rerr};
        return {true, "世界已还原"};
    }

    default:
        return {false, "未知子命令。用法：/hf 1 录制 /hf 2 停止 /hf 3 回放 /hf 4 停止回放 "
                       "/hf 5 列表 /hf 6 删除 /hf 7 拍快照 /hf 8 还原世界"};
    }
}

// ============================================================================
//  聊天兜底入口（CmdPlan=2 时用，也在 CmdPlan=1 时保留，双保险）
//  玩法：在聊天框输入 "/hf 3" 这种，就能触发，哪怕真命令注册失败了。
// ============================================================================
bool handleChatCommand(::Player* pl, std::string const& text) {
    if (text.size() < 4) return false;
    if (text.compare(0, 4, "/hf ") != 0) return false;

    // 解析第一个数字作为子命令，第二个数字作为参数
    int  sub = 0, arg = 0;
    int  got = 0;
    size_t i = 4;
    while (i < text.size()) {
        char c = text[i];
        if (c >= '0' && c <= '9') {
            if (got == 0) sub = sub * 10 + (c - '0');
            else if (got == 1) arg = arg * 10 + (c - '0');
        } else if (c == ' ') {
            if (sub != 0) ++got;
            if (got >= 2) break;
        } else {
            break;
        }
        ++i;
    }
    if (sub == 0) return false;

    auto res = runSub(pl, sub, arg);
    // 聊天模式下把结果直接发回给这个人（没有 CommandOutput 可用）
    try {
        auto pkt = ::TextPacket::createRawMessage(res.ok ? res.msg : ("§c" + res.msg));
        pl->sendNetworkPacket(pkt);
    } catch (...) {
    }
    return true;
}

// ============================================================================
//  命令注册
//    CmdPlan = 1 → CommandRegistrar（现代 LL 命令 API，有补全）
//    CmdPlan = 2 → 不注册真命令，完全靠聊天兜底
// ============================================================================
struct HfNum {
    int num;
};

void registerCommands() {
#if HF_CMD_PLAN != 1
    self().getLogger().warn("[HF] CmdPlan=2：不注册命令，请用聊天输入 /hf 1 这种方式操作");
    return;
#else

    // ★ 头文件实证（CommandRegistrar.h:50-54）：getInstance 需要 bool 参数，
    //   无参调用编不过。服务端插件用 getServerInstance()，语义也最清楚。
    auto& cmd = ll::command::CommandRegistrar::getServerInstance().getOrCreateCommand(
        "hf", "假人行为录制回放", ::CommandPermissionLevel::GameDirectors);

    // /hf —— 用法
    cmd.overload().execute([](::CommandOrigin const&, ::CommandOutput& out) {
        out.success(
            "§6【假人回放】§r/hf 1 开始录制 | /hf 2 停止保存 | /hf 3 回放 | /hf 4 停止回放 | "
            "/hf 5 列表 | /hf 6 <编号> 删除 | /hf 7 [半径] 拍快照 | /hf 8 还原世界");
    });

    auto runOne = [](::CommandOrigin const& origin, ::CommandOutput& out, int sub, int arg) {
        auto*   pl = originPlayer(origin);
        auto    res = runSub(pl, sub, arg);
        if (res.ok) out.success(res.msg);
        else out.error(res.msg);
    };

    cmd.overload().text("1").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 1, 0); });
    cmd.overload().text("2").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 2, 0); });
    cmd.overload().text("3").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 3, 0); });
    cmd.overload().text("4").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 4, 0); });
    cmd.overload().text("5").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 5, 0); });
    cmd.overload().text("7").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 7, 0); });
    cmd.overload().text("8").execute([=](::CommandOrigin const& o, ::CommandOutput& out) { runOne(o, out, 8, 0); });

    cmd.overload<HfNum>().text("3").required("num").execute(
        [=](::CommandOrigin const& o, ::CommandOutput& out, HfNum const& p) { runOne(o, out, 3, p.num); });
    cmd.overload<HfNum>().text("6").required("num").execute(
        [=](::CommandOrigin const& o, ::CommandOutput& out, HfNum const& p) { runOne(o, out, 6, p.num); });
    cmd.overload<HfNum>().text("7").required("num").execute(
        [=](::CommandOrigin const& o, ::CommandOutput& out, HfNum const& p) { runOne(o, out, 7, p.num); });
#endif
}

} // namespace hf_replay
