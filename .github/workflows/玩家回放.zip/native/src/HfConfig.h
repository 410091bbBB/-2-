#pragma once
// ============================================================================
//  hf-replay / HfConfig.h —— 编译期方案开关
//
//  ★★ 这个文件是「编译失败不用来回跑」的核心机制 ★★
//
//  为什么要有它：
//    BDS 的内部接口在不同版本间签名会变，我在沙箱里只能核对头文件、
//    没法真编译（Linux 上装不了 MSVC）。所以凡是**没 100% 把握**的地方，
//    我在代码里写了多套实现（Plan A / B / C），用下面的宏来选。
//
//  编译报错了怎么办：
//    1. 看报错里提到哪个文件、哪一行
//    2. 翻《编译失败自救手册.md》，找到对应的宏
//    3. 只改这一行的数字（比如 1 改成 2）
//    4. 重新上传、重新点一次编译
//    不需要动任何 .cpp 代码。
//
//  ★★ 为什么用 #define 而不是 if constexpr ★★
//    这里必须用宏（#if），因为：
//      「if constexpr 的假分支」只有在【模板里】才保证不被编译；
//      在普通函数里，假分支照样会被编译、照样报错。
//    也就是说，如果用 if constexpr 来切换两套喂包写法，
//    那么没被选中的那套仍然要能编过——那多写几套就完全没意义了。
//    用 #if 才是真正从源码层面把代码裁掉。
//    （这是我写完第一版后自己复查揪出来的坑，已全部改掉。）
//
//  已核对过的（LeviLamina 26.20.3 头文件实证）不需要改：
//    · ServerNetworkHandler::handle(NetworkIdentifier const&, 各包 const&)
//    · ServerNetworkHandler::handle(Player*, PlayerAuthInputPacket const&)  ← 静态
//    · SimulatedPlayer::create(...) 返回 SimulatedPlayer*（裸指针，不是 optional_ref）
//    · TextPacket::createRawMessage()   ← 注意：createSystemMessage 不存在
//    · BlockSource::setBlockSimple / getBlock / getBlockEntity
//    · BlockActor::save(CompoundTag&) / load(ILevel&, CompoundTag const&, DataLoadHelper&)
//    · Actor::save(CompoundTag&) / load(CompoundTag const&, DataLoadHelper&)
//    · ServerThreadExecutor::getDefault().executeAfter(fn, ll::chrono::ticks{n})
//    · ll::service::getServerNetworkHandler() → optional_ref（可隐式转指针）
// ============================================================================

// ---------------------------------------------------------------------------
// 【最关键】喂包方式：回放时把录到的原始字节怎么送进服务端
//
//   1 = 静态入口 handle(Player*, PlayerAuthInputPacket const&)
//       直接对假人对象喂，绕开网络标识(NID)匹配。
//       ★ 推荐首选：SimulatedPlayer 是服务端本地造的，它的 NID 未必能被
//         handle(nid, ...) 正确查到，静态版本没这个风险。
//
//   2 = 实例入口 handler->handle(nid, packet)
//       走完整网络通道，最接近真实玩家。若假人 NID 查不到玩家则无效。
//
//   3 = 双通道：静态为主，失败再走实例（日志会打 [FEED] 说明走了哪条）
//
// 报错含 "handle" / "no matching function" → 把 1 改成 2
// ---------------------------------------------------------------------------
#define HF_FEED_PLAN 1

// ---------------------------------------------------------------------------
// 假人创建方式
//
//   1 = 六参重载 create(name, pos, dimId, NotNullNonOwnerPtr<ServerNetworkHandler>, xuid, idOverride)
//   2 = 九参重载 create(name, pos, posDelta, rotation, spawnLoadedFromSave, dimId, handler, xuid, idOverride)
//       （头文件实证：SimulatedPlayer.h:242，正好 9 个参数，别多传）
//   3 = 不创建假人（只跑录制/回放逻辑，用来单独验证「录制」这一步是否正常）
//
// 报错含 "create" / "NotNullNonOwnerPtr" → 把 1 改成 2
// 假人死活造不出来、但录制正常 → 改成 3 先确认录制没问题
// ---------------------------------------------------------------------------
#define HF_BOT_PLAN 1

// ---------------------------------------------------------------------------
// 世界快照的三个通道（对应「通杀」设计：方块 / 容器NBT / 实体NBT）
//   1 = 开启    0 = 关闭（关掉就完全不编译这段代码）
//
// 默认：方块开、容器开、实体关。
//
// 容器为什么能开：BlockActor::load 需要 DataLoadHelper，而头文件里就有一个
// DefaultDataLoadHelper 可以直接栈上 new，不需要从服务端任何地方取 —— 已确认。
//
// 实体为什么还关着：实体快照要遍历区域内实体（BlockSource::getEntities 的
// 参数我没 100% 确认），而且「把录制期间被杀掉的怪重新生成出来」还需要
// 实体生成接口。这两项都属于没验证过的，留作第二版，
// 别拿主流程的编译成功率去赌。
// ---------------------------------------------------------------------------
#define HF_SNAPSHOT_BLOCK  1
#define HF_SNAPSHOT_TILE   1   // 箱子/熔炉/潜影盒：整条 NBT 搬运
#define HF_SNAPSHOT_ENTITY 0   // 实体：接口未验证，暂关

// 拍快照的默认半径（格）。这是立方体半径：
//   8  → 17³ ≈ 4.9 千方块
//   12 → 25³ ≈ 1.6 万方块
//   16 → 33³ ≈ 3.6 万方块（开始有感觉了）
//   24 → 49³ ≈ 11.7 万（明显卡顿，别用）
#define HF_SNAPSHOT_RADIUS 10

// ---------------------------------------------------------------------------
// 命令注册方式
//   1 = CommandRegistrar（现代 LL 命令 API，推荐）
//   2 = 聊天兜底：不注册真命令，改为监听聊天里以 "/hf " 开头的文本
//
// 报错含 "CommandRegistrar" / "CommandHandle" → 改 2
// 用 2 时游戏里没法 Tab 补全，但功能一样，能救命
// ---------------------------------------------------------------------------
#define HF_CMD_PLAN 1

// ---------------------------------------------------------------------------
// 录制白名单：抓哪些包
//   这三个是「行为」的全部来源，改动前先想清楚
//   144 PlayerAuthInput —— 移动/视角/跳/潜行/冲刺/挖/放/用物品，全在这一个包
//   33  Interact        —— 攻击/交互
//   44  Animate         —— 挥手
// ---------------------------------------------------------------------------
#define HF_CAPTURE_AUTH_INPUT 1
#define HF_CAPTURE_INTERACT   1
#define HF_CAPTURE_ANIMATE    1

// ---------------------------------------------------------------------------
// 回放时是否把假人保护起来（防止围观玩家打死假人导致后半场回放崩坏）
//
// ★ 默认关（0）！原因：Actor 上【没有】setInvulnerable 这个方法
//   （头文件里只有 isInvulnerableTo，是查询不是设置）。
//   我找了一圈没找到这个版本对应的无敌接口，所以默认关掉，
//   让这段代码干脆不参与编译 —— 宁可先没这功能，也别编不过。
//
//   等你确认了正确的接口名，把这里改 1、再把 Replayer.cpp 里那句换成
//   正确写法即可。在那之前：回放时别让别人打假人。
// ---------------------------------------------------------------------------
#define HF_PROTECT_BOT 0

// 日志详细程度：0 静默 / 1 关键节点 / 2 逐包（排错时开 2，正常用 1）
#define HF_LOG_LEVEL 1

// ---------------------------------------------------------------------------
// 下面这层是为了让 .cpp 里既能用宏做 #if 裁剪，又能顺手把值打进日志。
// 不需要改，跟着上面的宏走。
// ---------------------------------------------------------------------------
namespace hf_replay::cfg {
inline constexpr int  FeedPlan       = HF_FEED_PLAN;
inline constexpr int  BotPlan        = HF_BOT_PLAN;
inline constexpr bool SnapshotBlock  = HF_SNAPSHOT_BLOCK != 0;
inline constexpr bool SnapshotTile   = HF_SNAPSHOT_TILE != 0;
inline constexpr bool SnapshotEntity = HF_SNAPSHOT_ENTITY != 0;
inline constexpr int  SnapshotRadius = HF_SNAPSHOT_RADIUS;
inline constexpr int  CmdPlan        = HF_CMD_PLAN;
inline constexpr bool CaptureAuthInput = HF_CAPTURE_AUTH_INPUT != 0;
inline constexpr bool CaptureInteract  = HF_CAPTURE_INTERACT != 0;
inline constexpr bool CaptureAnimate   = HF_CAPTURE_ANIMATE != 0;
inline constexpr bool ProtectBot     = HF_PROTECT_BOT != 0;
inline constexpr int  LogLevel       = HF_LOG_LEVEL;
} // namespace hf_replay::cfg
