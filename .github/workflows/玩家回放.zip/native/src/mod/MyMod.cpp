#include "mod/MyMod.h"

#include "../Commands.h"
#include "../Recorder.h"
#include "../Replayer.h"

#include "ll/api/event/EventBus.h"
#include "ll/api/event/Listener.h"
#include "ll/api/event/ListenerBase.h"
#include "ll/api/event/player/PlayerChatEvent.h"
#include "ll/api/mod/RegisterHelper.h"

#include "mc/world/actor/player/Player.h"

namespace hf_replay {

HFReplayMod& HFReplayMod::getInstance() {
    static HFReplayMod instance;
    return instance;
}

bool HFReplayMod::load() {
    getSelf().getLogger().info("假人行为录制回放 正在加载");
    return true;
}

bool HFReplayMod::enable() {
    Recorder::getInstance().installHooks();

    // 注意：PlayerChatEvent 继承 ServerPlayerEvent，玩家对象是 self()（引用），
    // 且类型是 ServerPlayer&（不是 Player*）。创建后必须注册到 EventBus 才生效。
    auto chatListener = ll::event::Listener<ll::event::PlayerChatEvent>::create(
        [](ll::event::PlayerChatEvent& ev) {
            // PlayerChatEvent 继承 ServerPlayerEvent，玩家对象是 self()（返回 ServerPlayer&）
            ::Player* pl = static_cast<::Player*>(&ev.self());

            // 先看看是不是 "/hf 1" 这类兜底指令。是就执行掉，别记进录制内容。
            if (handleChatCommand(pl, ev.message())) return;

            Recorder::getInstance().tryCaptureChat(pl, ev.message());
        });
    ll::event::EventBus::getInstance().addListener(chatListener);
    mChatListener = std::move(chatListener);

    registerCommands();

    getSelf().getLogger().info(
        "已启用：/hf 1 开始录制 | /hf 2 结束保存 | /hf 3 回放 | /hf 4 停止回放 | "
        "/hf 5 列表 | /hf 6 删除 | /hf 7 拍快照 | /hf 8 还原世界");
    return true;
}

bool HFReplayMod::disable() {
    if (mChatListener) {
        // 移除监听的正确入口是 EventBus（ListenerBase 上没有 removeListener）
        ll::event::EventBus::getInstance().removeListener(mChatListener);
        mChatListener = nullptr;
    }
    if (Replayer::getInstance().isPlaying()) Replayer::getInstance().stop(false);
    if (Recorder::getInstance().isRecording()) Recorder::getInstance().stopAndSave();
    Recorder::getInstance().uninstallHooks();
    return true;
}

} // namespace hf_replay

LL_REGISTER_MOD(hf_replay::HFReplayMod, hf_replay::HFReplayMod::getInstance());
