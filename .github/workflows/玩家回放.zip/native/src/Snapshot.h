#pragma once

// ============================================================================
//  hf-replay / Snapshot.h —— 世界快照（「通杀」的核心）
//
//  设计哲学（照你的原话实现）：**不理解内容，只整体搬运。**
//
//  录制开始那一刻，把演出区域的整个世界状态拍下来：
//    · 方块   → 存坐标 + 方块指针
//    · 容器   → 存坐标 + 整条 CompoundTag（箱子里的附魔剑？它是这条 NBT
//               的一部分，恢复时整条写回，附魔/耐久/自定义名全自动回来，
//               压根不需要「处理附魔」这个概念）
//
//  为什么必须做这件事：
//    输入级回放是让服务端「重新算」。如果世界和录制时不一样（那方块已经被
//    挖掉了），假人再喂「挖它」的输入，算出来就是失败的 —— 行为变形。
//    所以**快照恢复不是附加功能，是输入级回放的前置依赖**。
//
//  恢复 = 快照恢复，不是逆操作：
//    逆操作要挨个写「方块怎么还原、箱子怎么还原、附魔怎么还原」，会漏。
//    快照不关心「发生过什么」，只关心「当时长什么样」，天然完备。
//
//  ★ 通杀的边界（提前说清）：
//    NBT 快照通杀的是「世界本体」。经济插件的钱、领地记录这类存在插件自己
//    数据库里的东西，快照盖不上去 —— 那是 Bedrock 架构决定的。
// ============================================================================

#include <string>
#include <unordered_map>
#include <vector>

#include "mc/deps/nbt/CompoundTag.h"
#include "mc/world/level/BlockPos.h"

class Actor;
class Block;
class BlockSource;

namespace hf_replay {

class Snapshot {
public:
    static Snapshot& getInstance();

    // 以某个实体为中心拍快照。radius 是立方体半径（格）
    // 返回失败原因，空串 = 成功
    std::string capture(::Actor* center, int radius, std::string const& tag);

    // 把世界恢复成某份快照的样子
    std::string restore(std::string const& tag);

    bool        has(std::string const& tag) const;
    void        erase(std::string const& tag);
    void        clearAll();
    std::vector<std::string> list() const;

    // 快照规模（方块数 / 容器数），用于日志
    void stats(std::string const& tag, size_t& blocks, size_t& tiles) const;

private:
    Snapshot() = default;

    struct Tile {
        ::BlockPos  pos;
        ::CompoundTag tag; // 整条 NBT，原样搬
    };

    struct Data {
        int  dimId = 0;
        // 拍快照时把方块源指针一起记下来。
        // 为什么不恢复时再从 Level 取维度：Level::getDimension 返回的是
        // WeakRef<Dimension>，它在不同版本上的取值写法（-> / .get() /
        // as_ptr）不完全一致，属于编译期风险。方块源指针在一次服务器会话
        // 内是稳定的，直接用它最省事也最不容易编译报错。
        ::BlockSource* bs = nullptr;
        ::BlockPos min{};
        ::BlockPos max{};
        std::vector<::BlockPos>        blockPos;
        std::vector<::Block const*>    blockPtr; // 方块是全局实例，指针在运行时稳定
        std::vector<Tile>              tiles;    // 容器（箱子/熔炉/潜影盒…）
    };

    std::unordered_map<std::string, Data> mStore;
};

} // namespace hf_replay
