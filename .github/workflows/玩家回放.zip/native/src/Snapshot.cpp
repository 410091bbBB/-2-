#include "Snapshot.h"

#include "HfConfig.h"

#include "ll/api/mod/NativeMod.h"
#include "ll/api/service/Bedrock.h"

#include "mc/dataloadhelper/DefaultDataLoadHelper.h"
#include "mc/world/actor/Actor.h"
#include "mc/world/level/BlockSource.h"
#include "mc/world/level/Level.h"
#include "mc/world/level/block/actor/BlockActor.h"

#include <string>

namespace hf_replay {

static ll::mod::Mod& self() { return *ll::mod::NativeMod::current(); }

Snapshot& Snapshot::getInstance() {
    static Snapshot inst;
    return inst;
}

// ---------------------------------------------------------------------------
//  拍快照
//
//  区域：以中心实体为原点的立方体，边长 = 2*radius+1
//  半径建议 8~16。24 以上会明显卡顿（方块数是立方级增长的）。
// ---------------------------------------------------------------------------
std::string Snapshot::capture(::Actor* center, int radius, std::string const& tag) {
    if (!center) return "找不到中心实体";
    if (radius < 1 || radius > 32) return "半径必须在 1~32 之间";
    if (tag.empty()) return "快照名不能为空";

    ::BlockSource& bs = center->getDimensionBlockSource();
    auto*          level = ll::service::getLevel().as_ptr();
    if (!level) return "服务端世界不可用";

    // Actor 上叫 getFeetBlockPos()，没有 getBlockPos()（头文件里确认过）
    ::BlockPos const origin = center->getFeetBlockPos();

    Data d;
    d.dimId = (int)center->getDimensionId();
    d.bs    = &bs;
    d.min   = ::BlockPos(origin.x - radius, origin.y - radius, origin.z - radius);
    d.max   = ::BlockPos(origin.x + radius, origin.y + radius, origin.z + radius);

    // 世界上下限钳制，别越界
    if (d.min.y < -64) d.min.y = -64;
    if (d.max.y > 319) d.max.y = 319;

    for (int x = d.min.x; x <= d.max.x; ++x) {
        for (int y = d.min.y; y <= d.max.y; ++y) {
            for (int z = d.min.z; z <= d.max.z; ++z) {
#if (HF_SNAPSHOT_BLOCK || HF_SNAPSHOT_TILE)
                ::BlockPos pos(x, y, z);
#endif

                // ---- 通道一：方块 ----
#if HF_SNAPSHOT_BLOCK
                d.blockPos.push_back(pos);
                d.blockPtr.push_back(&bs.getBlock(pos));
#endif

                // ---- 通道二：容器（整条 NBT 搬运）----
#if HF_SNAPSHOT_TILE
                {
                    auto* tile = bs.getBlockEntity(pos);
                    if (tile) {
                        ::CompoundTag nbt;
                        tile->save(nbt); // 整个 BlockActor 序列化，含全部物品与附魔
                        d.tiles.push_back(Tile{pos, std::move(nbt)});
                    }
                }
#endif
            }
        }
    }

    mStore[tag] = std::move(d);

#if HF_LOG_LEVEL >= 1
    self().getLogger().info(
        "[HF] 快照 {} 拍摄完成：{} 方块 / {} 容器，半径 {}",
        tag, d.blockPos.size(), d.tiles.size(), radius);
#endif
    return "";
}

// ---------------------------------------------------------------------------
//  恢复
//
//  顺序很重要：先铺方块（会把箱子这类容器一并重建），
//  再把容器的整条 NBT 灌回去。反过来会被方块覆盖掉。
// ---------------------------------------------------------------------------
std::string Snapshot::restore(std::string const& tag) {
    auto it = mStore.find(tag);
    if (it == mStore.end()) return "找不到快照：" + tag;

#if HF_SNAPSHOT_TILE
    auto* level = ll::service::getLevel().as_ptr();
    if (!level) return "服务端世界不可用";
#endif

    Data const& d = it->second;

    // 直接用拍快照时记下的方块源指针（见 Snapshot.h 里的说明）
    ::BlockSource* bs = d.bs;
    if (!bs) return "这份快照没记下方块源，无法恢复";

#if HF_SNAPSHOT_TILE
    ::DefaultDataLoadHelper helper; // 栈上即可，NBT 恢复需要它
#endif

    // ---- 恢复方块 ----
#if HF_SNAPSHOT_BLOCK
    for (size_t i = 0; i < d.blockPos.size(); ++i) {
        if (!d.blockPtr[i]) continue;
        bs->setBlockSimple(d.blockPos[i], *d.blockPtr[i]);
    }
#endif

    // ---- 恢复容器：整条 NBT 写回 ----
#if HF_SNAPSHOT_TILE
    for (auto const& t : d.tiles) {
        auto* tile = bs->getBlockEntity(t.pos);
        if (!tile) continue; // 方块被换掉了导致容器不存在，跳过
        try {
            tile->load(*level, t.tag, helper);
        } catch (...) {
            // 单个容器失败不要中断整场恢复
        }
    }
#endif

#if HF_LOG_LEVEL >= 1
    self().getLogger().info("[HF] 快照 {} 已恢复", tag);
#endif
    return "";
}

bool Snapshot::has(std::string const& tag) const { return mStore.count(tag) != 0; }

void Snapshot::erase(std::string const& tag) { mStore.erase(tag); }

void Snapshot::clearAll() { mStore.clear(); }

std::vector<std::string> Snapshot::list() const {
    std::vector<std::string> out;
    out.reserve(mStore.size());
    for (auto const& kv : mStore) out.push_back(kv.first);
    return out;
}

void Snapshot::stats(std::string const& tag, size_t& blocks, size_t& tiles) const {
    auto it = mStore.find(tag);
    if (it == mStore.end()) {
        blocks = 0;
        tiles  = 0;
        return;
    }
    blocks = it->second.blockPos.size();
    tiles  = it->second.tiles.size();
}

} // namespace hf_replay
