#pragma once

#include <string>

class Player;

namespace hf_replay {

// 注册 /hf 命令（CmdPlan 为 2 时不注册，改用聊天兜底）
void registerCommands();

// 聊天兜底入口：识别玩家在聊天框输入的 "/hf 1" 这类文本并执行。
// 命中并已处理返回 true。命令注册那套万一挂了，这条命还在。
bool handleChatCommand(::Player* pl, std::string const& text);

} // namespace hf_replay
